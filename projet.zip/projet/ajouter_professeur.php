<?php
require_once 'db.php';
require_admin();

if (is_post()) {
    $stmt = $pdo->prepare("INSERT INTO users (role, nom, email, password) VALUES ('professeur', ?, ?, ?)");
    $stmt->execute([
        $_POST['nom'],
        $_POST['email'],
        $_POST['password'] 
    ]);
    redirect('admin_dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Ajouter professeur — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header"><div class="left"><span class="brand-logo small">FSN</span><h2>Ajouter un professeur</h2></div></header>
<main class="container">
  <form method="post" class="form-grid card">
    <div class="form-field"><label>Nom</label><input name="nom" required></div>
    <div class="form-field"><label>Email</label><input type="email" name="email" required></div>
    <div class="form-field"><label>Mot de passe</label><input type="text" name="password" required></div>
    <button class="btn primary">Ajouter</button>
    <a class="btn" href="admin_dashboard.php">Retour</a>
  </form>
</main>
</body>
</html>
