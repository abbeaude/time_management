<?php
require_once 'db.php';
require_admin();

require_once __DIR__ . '/lib/fpdf.php'; 


$creneaux = [
  ['07:30','09:30'],
  ['09:30','11:30'],
  ['11:30','13:30'],
  ['13:30','15:30'],
  ['15:30','17:30'],
  ['17:30','19:30'],
];
$jours = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];


$stmt = $pdo->query("
  SELECT s.*, m.intitule, sa.code AS salle_code, u.nom AS professeur_nom
  FROM seances s
  JOIN modules m ON m.id = s.module_id
  JOIN salles sa ON sa.id = s.salle_id
  JOIN users u ON u.id = s.professeur_id
  WHERE s.statut='prévu'
");
$rows = $stmt->fetchAll();

function toMinutes($time) {
    list($h,$m) = explode(':',$time);
    return $h*60 + $m;
}

$pdf = new FPDF('L','mm','A4'); 
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,utf8_decode("Emploi du temps global (Vue administrateur)"),0,1,'C');
$pdf->Ln(5);


$pdf->SetFont('Arial','B',10);
$pdf->Cell(30,10,'Jour',1,0,'C');
foreach ($creneaux as $c) {
    $pdf->Cell(40,10,$c[0].'-'.$c[1],1,0,'C');
}
$pdf->Ln();


$pdf->SetFont('Arial','',8);
foreach ($jours as $j) {
   
    $rowHeight = 30;
    $pdf->Cell(30,$rowHeight,utf8_decode($j),1,0,'C');

    foreach ($creneaux as $c) {
        $start = toMinutes($c[0]);
        $end   = toMinutes($c[1]);
        $cellContent = '';
        foreach ($rows as $s) {
            if ($s['jour']===$j) {
                $deb = toMinutes($s['heure_debut']);
                $fin = toMinutes($s['heure_fin']);
                if ($deb >= $start && $fin <= $end) {
                    $cellContent .= "Module: ".$s['intitule']."\n";
                    $cellContent .= "Salle: ".$s['salle_code']."\n";
                    $cellContent .= "Prof: ".$s['professeur_nom']."\n";
                    $cellContent .= "Horaire: ".$s['heure_debut']."-".$s['heure_fin']."\n";
                }
            }
        }
        if ($cellContent==='') $cellContent = "—";

       
        $x = $pdf->GetX();
        $y = $pdf->GetY();

        
        $pdf->MultiCell(40,5,utf8_decode($cellContent),0,'L');

        
        $pdf->SetXY($x+40,$y);
        
        $pdf->Rect($x,$y,40,$rowHeight);
    }
    $pdf->Ln($rowHeight);
}

$pdf->Output('I','emploi_global.pdf');
