<?php
require_once 'db.php';
require_admin();

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM notifications WHERE id=?")->execute([$_GET['delete']]);
}

$list = $pdo->query("SELECT * FROM notifications ORDER BY created_at DESC")->fetchAll();
$pdo->query("UPDATE notifications SET lu=1 WHERE lu=0");

?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="utf-8"><title>Notifications</title><link rel="stylesheet" href="style.css"></head>
<body>
<header class="app-header"><h2>Notifications</h2><a href="admin_dashboard.php">Retour</a></header>
<main class="container">
  <ul class="list">
    <?php foreach ($list as $n): ?>
      <li>
        <div class="list-title"><?= htmlspecialchars($n['titre']) ?></div>
        <div class="list-sub"><?= nl2br(htmlspecialchars($n['message'])) ?></div>
        <div class="list-meta"><?= $n['audience'] ?> — <?= $n['created_at'] ?></div>
        <a class="btn danger" href="?delete=<?= $n['id'] ?>" onclick="return confirm('Supprimer cette notification ?')">Supprimer</a>
      </li>
    <?php endforeach; ?>
  </ul>
</main>
</body>
</html>
