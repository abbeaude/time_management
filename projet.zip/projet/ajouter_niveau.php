<?php
require_once 'db.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    if ($nom !== "") {
        $stmt = $pdo->prepare("INSERT INTO niveaux (nom) VALUES (?)");
        $stmt->execute([$nom]);
        header("Location: liste_niveaux.php?msg=" . urlencode("Niveau ajouté avec succès"));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Ajouter un niveau</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h2>Ajouter un niveau</h2>
  <a href="admin_dashboard.php">⬅ Retour au tableau de bord</a>
</header>

<main class="container">
  <form method="post" class="card">
    <label>Nom du niveau</label>
    <input type="text" name="nom" required placeholder="Ex: L1, L2, L3, M1, M2">
    <button type="submit" class="btn primary">Ajouter</button>
  </form>
</main>
</body>
</html>
