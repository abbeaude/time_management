<?php
require_once 'db.php';
require_admin();

if (is_post()) {
    $stmt = $pdo->prepare("INSERT INTO departements (nom) VALUES (?)");
    $stmt->execute([$_POST['nom']]);
    redirect('admin_dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Ajouter département — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header"><div class="left"><span class="brand-logo small">FSN</span><h2>Ajouter un département</h2></div></header>
<main class="container">
  <form method="post" class="form-grid card">
    <div class="form-field"><label>Nom</label><input name="nom" required></div>
    <button class="btn primary">Ajouter</button>
    <a class="btn" href="admin_dashboard.php">Retour</a>
  </form>
</main>
</body>
</html>
