
document.addEventListener('DOMContentLoaded', () => {
    
    document.querySelectorAll('.btn').forEach(btn => {
      btn.addEventListener('mousedown', () => btn.style.transform = 'scale(0.98)');
      btn.addEventListener('mouseup', () => btn.style.transform = '');
      btn.addEventListener('mouseleave', () => btn.style.transform = '');
    });
  
   
    setTimeout(() => {
      document.querySelectorAll('.alert.success').forEach(a => a.remove());
    }, 5000);
  });
  