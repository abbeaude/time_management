<?php
require_once 'db.php';
require_admin();


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM filieres WHERE id=?");
    $stmt->execute([$_POST['delete_id']]);
    header("Location: liste_filieres.php?msg=" . urlencode("Filière supprimée avec succès"));
    exit;
}


$filieres = $pdo->query("
  SELECT f.id, f.nom, d.nom AS departement_nom
  FROM filieres f
  JOIN departements d ON d.id = f.departement_id
  ORDER BY d.nom ASC, f.nom ASC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Liste des filières</title>
<link rel="stylesheet" href="style.css">
<style>
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
table th, table td {
  border: 1px solid #333;
  padding: 8px;
  text-align: left;
}
table th {
  background: #003366;
  color: #fff;
}
.actions {
  display: flex;
  gap: 8px;
}
</style>
</head>
<body>
<header class="app-header">
  <h2>Liste des filières</h2>
  <a href="admin_dashboard.php">⬅ Retour</a>
</header>

<main class="container">
  <?php if (!empty($_GET['msg'])): ?>
    <p style="color:green;font-weight:bold;"><?= htmlspecialchars($_GET['msg']) ?></p>
  <?php endif; ?>

  <table class="card">
    <tr>
      <th>Nom</th>
      <th>Département</th>
      <th>Actions</th>
    </tr>
    <?php foreach ($filieres as $f): ?>
      <tr>
        <td><?= htmlspecialchars($f['nom']) ?></td>
        <td><?= htmlspecialchars($f['departement_nom']) ?></td>
        <td class="actions">
          <a class="btn" href="update_filiere.php?id=<?= $f['id'] ?>">Modifier</a>
          <form method="post" style="display:inline;" onsubmit="return confirm('Supprimer cette filière ?')">
            <input type="hidden" name="delete_id" value="<?= $f['id'] ?>">
            <button type="submit" class="btn danger">Supprimer</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
