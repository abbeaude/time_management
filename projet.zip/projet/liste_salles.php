<?php
require_once 'db.php';
require_admin();

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM salles WHERE id=?")->execute([$_GET['delete']]);
}

$salles = $pdo->query("SELECT * FROM salles ORDER BY code")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="utf-8"><title>Liste des salles</title><link rel="stylesheet" href="style.css"></head>
<body>
<header class="app-header"><h2>Liste des salles</h2><a href="admin_dashboard.php">Retour</a></header>
<main class="container">
  <table class="card">
    <tr><th>Code</th><th>Capacité</th><th>Actions</th></tr>
    <?php foreach ($salles as $s): ?>
      <tr>
        <td><?= htmlspecialchars($s['code']) ?></td>
        <td><?= htmlspecialchars($s['capacite']) ?></td>
        <td>
          <a class="btn" href="update_salle.php?id=<?= $s['id'] ?>">Modifier</a>
          <a class="btn danger" href="?delete=<?= $s['id'] ?>" onclick="return confirm('Supprimer cette salle ?')">Supprimer</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
