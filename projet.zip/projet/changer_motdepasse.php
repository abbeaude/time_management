<?php
require_once 'db.php';
require_login();

$userId = $_SESSION['user']['id'];
$role   = $_SESSION['user']['role'];

if (is_post()) {
    $ancien = trim($_POST['ancien_password'] ?? '');
    $nouveau = trim($_POST['nouveau_password'] ?? '');
    $confirm = trim($_POST['confirm_password'] ?? '');

   
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id=?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();

    if (!$row || $row['password'] !== $ancien) {
        $error = "Ancien mot de passe incorrect.";
    } elseif ($nouveau === '') {
        $error = "Le nouveau mot de passe ne peut pas être vide.";
    } elseif ($nouveau !== $confirm) {
        $error = "La confirmation ne correspond pas au nouveau mot de passe.";
    } else {
      
        $stmt = $pdo->prepare("UPDATE users SET password=? WHERE id=?");
        $stmt->execute([$nouveau, $userId]);
        $success = "Mot de passe mis à jour avec succès.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Changer le mot de passe</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header">
  <div class="left"><span class="brand-logo small">FSN</span>
  <h2>Changer le mot de passe</h2></div>
  <nav class="nav"><a href="<?= $role==='admin'?'admin_dashboard.php':'professeur_dashboard.php' ?>">Retour</a></nav>
</header>
<main class="container">
  <?php if (!empty($error)): ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <?php if (!empty($success)): ?><div class="alert success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

  <form method="post" class="form-grid card">
    <div class="form-field full">
      <label>Ancien mot de passe</label>
      <input type="password" name="ancien_password" required>
    </div>
    <div class="form-field full">
      <label>Nouveau mot de passe</label>
      <input type="password" name="nouveau_password" required>
    </div>
    <div class="form-field full">
      <label>Confirmer le nouveau mot de passe</label>
      <input type="password" name="confirm_password" required>
    </div>
    <button class="btn primary">Enregistrer</button>
  </form>
</main>
</body>
</html>
