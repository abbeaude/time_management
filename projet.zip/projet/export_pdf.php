<?php
require_once 'db.php';
require_admin();

$profId = (int)($_GET['professeur_id'] ?? 0);
if (!$profId) { redirect('emploi_professeur.php'); }

$prof = $pdo->prepare("SELECT * FROM users WHERE id=?");
$prof->execute([$profId]);
$prof = $prof->fetch();
if (!$prof) { redirect('emploi_professeur.php'); }

$seances = $pdo->prepare("
  SELECT s.*, m.intitule, sa.code AS salle_code
  FROM seances s
  JOIN modules m ON m.id = s.module_id
  JOIN salles sa ON sa.id = s.salle_id
  WHERE s.professeur_id=? AND s.statut='prévu'
  ORDER BY FIELD(jour,'Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'), heure_debut
");
$seances->execute([$profId]);
$rows = $seances->fetchAll();

require_once __DIR__ . '/lib/fpdf.php'; 

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, utf8_decode("Emploi du temps — " . $prof['nom']), 0, 1, 'C');

$pdf->SetFont('Arial', '', 12);
$pdf->Ln(4);
$jours = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];

foreach ($jours as $j) {
    $dayRows = array_filter($rows, fn($r) => $r['jour'] === $j);
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 8, utf8_decode($j), 0, 1);
    $pdf->SetFont('Arial', '', 11);

    if (!$dayRows) {
        $pdf->Cell(0, 6, utf8_decode("— Aucune séance —"), 0, 1);
    } else {
        foreach ($dayRows as $r) {
            $line = sprintf("%s | %s - %s | Salle %s",
                $r['intitule'], $r['heure_debut'], $r['heure_fin'], $r['salle_code']
            );
            $pdf->Cell(0, 6, utf8_decode($line), 0, 1);
        }
    }
    $pdf->Ln(2);
}

$pdf->Output('I', 'emploi_'.$profId.'.pdf');
