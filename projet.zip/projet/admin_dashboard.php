<?php
require_once 'db.php';
require_admin();


$counts['non_repondus'] = $pdo->query("SELECT COUNT(*) FROM commentaires WHERE reponse IS NULL")->fetchColumn();
$counts = [
    'professeurs' => $pdo->query("SELECT COUNT(*) FROM users WHERE role='professeur'")->fetchColumn(),
    'departements' => $pdo->query("SELECT COUNT(*) FROM departements")->fetchColumn(),
    'filieres' => $pdo->query("SELECT COUNT(*) FROM filieres")->fetchColumn(),
    'modules' => $pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn(),
    'salles' => $pdo->query("SELECT COUNT(*) FROM salles")->fetchColumn(),
    'seances' => $pdo->query("SELECT COUNT(*) FROM seances WHERE statut='prévu'")->fetchColumn(),
    'annulees' => $pdo->query("SELECT COUNT(*) FROM seances WHERE statut='annulé'")->fetchColumn(),
    'niveaux' => $pdo->query("SELECT COUNT(*) FROM niveaux")->fetchColumn(),
];
$notifications = $pdo->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5")->fetchAll();
$nbNonLues = $pdo->query("SELECT COUNT(*) FROM notifications WHERE lu=0")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Tableau de bord — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header">
  <div class="left">
    <span class="brand-logo small">FSN</span>
    <h2>Tableau de bord</h2>
  </div>
  
  <nav class="nav">
    <a href="admin_dashboard.php" class="btn">Accueil</a>
    <a href="statistiques.php" class="btn">Statistiques</a>
    <!-- <a href="notifications.php">Notifications</a> -->
  <?php if ($nbNonLues > 0): ?>
    <span class="badge"><?= $nbNonLues ?></span>
  <?php endif; ?>
    </a>
    <a class="btn" href="liste_commentaires.php">Commentaires des professeurs</a>
    <a class="btn" href="changer_motdepasse.php" style="color:green ;" >Changer le mot de passe</a>
    <a href="logout.php" class="btn" style="color: red;">Déconnexion</a>
  </nav>
</header>

<main class="container">
  <section class="grid cards">
    <div class="card stat"><h3>Professeurs</h3><div class="big"><?= $counts['professeurs'] ?></div></div>
    <div class="card stat"><h3>Départements</h3><div class="big"><?= $counts['departements'] ?></div></div>
    <div class="card stat"><h3>Filières</h3><div class="big"><?= $counts['filieres'] ?></div></div>
    <div class="card stat"><h3>Modules</h3><div class="big"><?= $counts['modules'] ?></div></div>
    <div class="card stat"><h3>Salles</h3><div class="big"><?= $counts['salles'] ?></div></div>
    <div class="card stat"><h3>Séances prévues</h3><div class="big"><?= $counts['seances'] ?></div></div>
    <div class="card stat"><h3>Séances annulées</h3><div class="big"><?= $counts['annulees'] ?></div></div>
    <div class="card stat"><h3>Niveaux</h3><div class="big"><?= $counts['niveaux'] ?></div></div>

    
  </section>

  <section class="panel">
    <h3>Actions rapides</h3>
    <div class="grid actions">
      <a class="btn" href="ajouter_professeur.php">Ajouter professeur</a>
      <a class="btn" href="ajouter_departement.php">Ajouter département</a>
      <a class="btn" href="ajouter_filiere.php">Ajouter filière</a>
      <a class="btn" href="ajouter_module.php">Ajouter module</a>
      <a class="btn" href="ajouter_salle.php">Ajouter salle</a>
      <a class="btn" href="ajouter_seance.php">Planifier une séance</a>
      <a class="btn" href="emploi_professeur.php">Emploi par professeur</a>
     
      <a class="btn" href="ajouter_niveau.php">Ajouter niveau</a>

    </div>
  </section>

  <section class="panel">
  <h3>Gestion des données</h3>
  <div class="grid actions">
  <a class="btn" href="emploi_global.php">Emploi du temps global</a>
    <a class="btn" href="liste_professeurs.php">Liste des professeurs</a>
    <a class="btn" href="liste_departements.php">Liste des départements</a>
    <a class="btn" href="liste_filieres.php">Liste des filières</a>
    <a class="btn" href="liste_modules.php">Liste des modules</a>
    <a class="btn" href="liste_salles.php">Liste des salles</a>
    <a class="btn" href="liste_niveaux.php">Liste des niveaux</a>
    <a class="btn" href="export_pdf.php">Exporter en PDF</a>

  </div>
</section>


  <section class="panel">
    <!-- <h3>Dernières notifications</h3> -->
    <ul class="list">
      <?php foreach ($notifications as $n): ?>
        <li>
          <div class="list-title"><?= htmlspecialchars($n['titre']) ?></div>
          <div class="list-sub"><?= htmlspecialchars($n['message']) ?></div>
          <div class="list-meta"><?= htmlspecialchars($n['audience']) ?> — <?= htmlspecialchars($n['created_at']) ?></div>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
</main>
<script src="script.js"></script>
</body>
</html>
