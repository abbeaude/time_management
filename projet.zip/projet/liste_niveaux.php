<?php
require_once 'db.php';
require_admin();

$stmt = $pdo->query("SELECT id, nom FROM niveaux ORDER BY id ASC");
$niveaux = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Liste des niveaux</title>
<link rel="stylesheet" href="style.css">
<style>
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
table th, table td {
  border: 1px solid #333;
  padding: 10px;
  text-align: left;
}
table th {
  background: #003366;
  color: #fff;
}
.actions a {
  margin-right: 8px;
  text-decoration: none;
  padding: 5px 10px;
  border-radius: 4px;
  color: #fff;
}
.delete { background: #c0392b; }
</style>
</head>
<body>
<header>
  <h2>Liste des niveaux</h2>
  <a href="admin_dashboard.php">⬅ Retour au tableau de bord</a>
</header>

<main>
  <?php if (!empty($_GET['msg'])): ?>
    <p style="color:green;font-weight:bold;"><?= htmlspecialchars($_GET['msg']) ?></p>
  <?php endif; ?>

  <table>
    <tr>
      <th>ID</th>
      <th>Nom</th>
      <th>Actions</th>
    </tr>
    <?php foreach ($niveaux as $n): ?>
      <tr>
        <td><?= htmlspecialchars($n['id']) ?></td>
        <td><?= htmlspecialchars($n['nom']) ?></td>
        <td class="actions">
          <a class="delete" href="supprimer_niveau.php?id=<?= $n['id'] ?>" onclick="return confirm('Supprimer ce niveau ?')">Supprimer</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
