<?php
$DB_HOST = 'localhost';
$DB_NAME = 'gestion_emploi';
$DB_USER = 'root';
$DB_PASS = ''; 

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die("Erreur de connexion: " . $e->getMessage());
}

function redirect($path) {
    header("Location: $path");
    exit;
}

function is_post() { return $_SERVER['REQUEST_METHOD'] === 'POST'; }

function require_admin() {
    session_start();
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
        header("Location: index.php?err=auth");
        exit;
    }
}

function require_login() {
    session_start();
    if (!isset($_SESSION['user'])) {
        header("Location: index.php?err=auth");
        exit;
    }
}
