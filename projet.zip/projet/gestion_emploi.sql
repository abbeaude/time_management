
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";




CREATE TABLE `departements` (
  `id` int(11) NOT NULL,
  `nom` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `filieres` (
  `id` int(11) NOT NULL,
  `departement_id` int(11) NOT NULL,
  `nom` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `intitule` varchar(200) NOT NULL,
  `filiere_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `audience` enum('tous','professeurs') NOT NULL DEFAULT 'tous',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `salles` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `capacite` int(11) NOT NULL DEFAULT 30
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `seances` (
  `id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `professeur_id` int(11) NOT NULL,
  `salle_id` int(11) NOT NULL,
  `jour` enum('Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi') NOT NULL,
  `heure_debut` time NOT NULL,
  `heure_fin` time NOT NULL,
  `statut` enum('prévu','annulé') NOT NULL DEFAULT 'prévu',
  `commentaire` varchar(255) DEFAULT NULL
) ;



CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` enum('admin','professeur') NOT NULL DEFAULT 'professeur',
  `nom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `users` (`id`, `role`, `nom`, `email`, `password`, `created_at`) VALUES
(1, 'admin', 'Administrateur', 'admin@fs-uni-ndere.cm', '1234', '2026-01-09 09:33:04');


ALTER TABLE `departements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nom` (`nom`);


ALTER TABLE `filieres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `departement_id` (`departement_id`,`nom`);


ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `fk_mod_fil` (`filiere_id`);


ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `salles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);


ALTER TABLE `seances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_sea_mod` (`module_id`),
  ADD KEY `fk_sea_prof` (`professeur_id`),
  ADD KEY `fk_sea_salle` (`salle_id`);


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);


ALTER TABLE `departements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `filieres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `salles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `seances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


ALTER TABLE `filieres`
  ADD CONSTRAINT `fk_fil_dep` FOREIGN KEY (`departement_id`) REFERENCES `departements` (`id`) ON DELETE CASCADE;


ALTER TABLE `modules`
  ADD CONSTRAINT `fk_mod_fil` FOREIGN KEY (`filiere_id`) REFERENCES `filieres` (`id`) ON DELETE CASCADE;


ALTER TABLE `seances`
  ADD CONSTRAINT `fk_sea_mod` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sea_prof` FOREIGN KEY (`professeur_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sea_salle` FOREIGN KEY (`salle_id`) REFERENCES `salles` (`id`);
COMMIT;

