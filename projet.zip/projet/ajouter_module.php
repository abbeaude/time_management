<?php
require_once 'db.php';
require_admin();
$filieres = $pdo->query("SELECT id, nom FROM filieres ORDER BY nom")->fetchAll();

if (is_post()) {
    $stmt = $pdo->prepare("INSERT INTO modules (code, intitule, filiere_id) VALUES (?, ?, ?)");
    $stmt->execute([$_POST['code'], $_POST['intitule'], $_POST['filiere_id']]);
    redirect('admin_dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Ajouter module — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header"><div class="left"><span class="brand-logo small">FSN</span><h2>Ajouter un module</h2></div></header>
<main class="container">
  <form method="post" class="form-grid card">
    <div class="form-field"><label>Code</label><input name="code" required></div>
    <div class="form-field"><label>Intitulé</label><input name="intitule" required></div>
    <div class="form-field">
      <label>Filière</label>
      <select name="filiere_id" required>
        <?php foreach ($filieres as $f): ?>
          <option value="<?= $f['id'] ?>"><?= htmlspecialchars($f['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button class="btn primary">Ajouter</button>
    <a class="btn" href="admin_dashboard.php">Retour</a>
  </form>
</main>
</body>
</html>
