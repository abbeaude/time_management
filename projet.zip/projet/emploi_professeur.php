<?php
require_once 'db.php';
require_admin();

$profs = $pdo->query("SELECT id, nom FROM users WHERE role='professeur' ORDER BY nom")->fetchAll();

$seances = [];
$profId = (int)($_GET['professeur_id'] ?? 0);
if ($profId) {
    $st = $pdo->prepare("
      SELECT s.*, m.intitule, sa.code AS salle_code
      FROM seances s
      JOIN modules m ON m.id = s.module_id
      JOIN salles sa ON sa.id = s.salle_id
      WHERE s.professeur_id=? AND s.statut='prévu'
      ORDER BY FIELD(jour,'Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'), heure_debut
    ");
    $st->execute([$profId]);
    $seances = $st->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Emploi du temps — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header">
  <div class="left"><span class="brand-logo small">FSN</span><h2>Emploi du temps par professeur</h2></div>
  <nav class="nav"><a href="admin_dashboard.php">Accueil</a></nav>
</header>
<main class="container">
  <form method="get" class="form-grid card">
    <div class="form-field">
      <label>Professeur</label>
      <select name="professeur_id" required>
        <option value="">— choisir —</option>
        <?php foreach ($profs as $p): ?>
          <option value="<?= $p['id'] ?>" <?= $p['id']===$profId?'selected':'' ?>><?= htmlspecialchars($p['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button class="btn primary">Afficher</button>
    <?php if ($profId): ?>
      <a class="btn" href="export_pdf.php?professeur_id=<?= $profId ?>">Exporter PDF</a>
    <?php endif; ?>
  </form>

  <?php if ($profId): ?>
    <section class="panel">
      <?php
      $jours = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
      foreach ($jours as $j) {
          echo "<h3>$j</h3><div class='grid cards'>";
          $rows = array_filter($seances, fn($s) => $s['jour'] === $j);
          if (!$rows) {
              echo "<div class='card'>Aucune séance.</div>";
          } else {
              foreach ($rows as $s) {
                  echo "<div class='card'>
                          <div class='list-title'>".htmlspecialchars($s['intitule'])."</div>
                          <div class='list-sub'>Salle ".htmlspecialchars($s['salle_code'])."</div>
                          <div class='list-meta'>".$s['heure_debut']." - ".$s['heure_fin']."</div>
                          <div class='list-meta muted'>".htmlspecialchars($s['commentaire'] ?? '')."</div>
                          <div class='actions'>
                            <a class='btn' href='update_seance.php?id=".$s['id']."'>Modifier</a>
                            <a class='btn danger' href='annuler_seance.php?id=".$s['id']."' onclick='return confirm(\"Annuler cette séance ?\")'>Annuler</a>
                          </div>
                        </div>";
              }
          }
          echo "</div>";
      }
      ?>
    </section>
  <?php endif; ?>
</main>
<script src="script.js"></script>
</body>
</html>
