
CREATE DATABASE IF NOT EXISTS gestion_emploi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_emploi;


CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role ENUM('admin','professeur') NOT NULL DEFAULT 'professeur',
  nom VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL, 
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS departements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(120) UNIQUE NOT NULL
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS filieres (
  id INT AUTO_INCREMENT PRIMARY KEY,
  departement_id INT NOT NULL,
  nom VARCHAR(120) NOT NULL,
  CONSTRAINT fk_fil_dep FOREIGN KEY (departement_id) REFERENCES departements(id) ON DELETE CASCADE,
  UNIQUE(departement_id, nom)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS salles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  capacite INT NOT NULL DEFAULT 30
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS modules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  intitule VARCHAR(200) NOT NULL,
  filiere_id INT NOT NULL,
  CONSTRAINT fk_mod_fil FOREIGN KEY (filiere_id) REFERENCES filieres(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS seances (
  id INT AUTO_INCREMENT PRIMARY KEY,
  module_id INT NOT NULL,
  professeur_id INT NOT NULL,
  salle_id INT NOT NULL,
  jour ENUM('Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi') NOT NULL,
  heure_debut TIME NOT NULL,
  heure_fin TIME NOT NULL,
  statut ENUM('prévu','annulé') NOT NULL DEFAULT 'prévu',
  commentaire VARCHAR(255),
  CONSTRAINT fk_sea_mod FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE,
  CONSTRAINT fk_sea_prof FOREIGN KEY (professeur_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_sea_salle FOREIGN KEY (salle_id) REFERENCES salles(id) ON DELETE RESTRICT,
  CONSTRAINT chk_heures CHECK (heure_fin > heure_debut)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  audience ENUM('tous','professeurs') NOT NULL DEFAULT 'tous',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


INSERT INTO users (role, nom, email, password)
VALUES ('admin','Administrateur','admin@fs-uni-ndere.cm','1234')
ON DUPLICATE KEY UPDATE email=email;
