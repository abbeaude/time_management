<?php
require_once 'db.php';
require_admin();


$creneaux = [
  ['07:30','09:30'],
  ['09:30','11:30'],
  ['11:30','13:30'],
  ['13:30','15:30'],
  ['15:30','17:30'],
  ['17:30','19:30'],
  ['19:30','20:30']
];
$jours = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];


$seances = $pdo->query("
  SELECT s.*, m.intitule, sa.code AS salle_code, u.nom AS professeur_nom
  FROM seances s
  JOIN modules m ON m.id=s.module_id
  JOIN salles sa ON sa.id=s.salle_id
  JOIN users u ON u.id=s.professeur_id
  WHERE s.statut='prévu'
")->fetchAll();


function toMinutes($time) {
    list($h,$m) = explode(':',$time);
    return $h*60 + $m;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Emploi du temps global</title>
<link rel="stylesheet" href="style.css">
<style>

table.emploi {
  width: 100%;
  border-collapse: collapse;
  margin-top: 30px;
}

table.emploi th, table.emploi td {
  border: 2px solid #333; 
  text-align: center;
  padding: 15px;
  min-width: 130px;
}

table.emploi th {
  background: #003366;
  color: #fff;
  font-size: 14px;
}

table.emploi td {
  background:rgb(21, 20, 20);
  vertical-align: top;
}

.jour {
  background: #e0e0e0;
  font-weight: bold;
}

.case {
  height: 120px;
}

.seance {
  background: linear-gradient(135deg, #4a90e2, #357ab7);
  color: #fff;
  border-radius: 8px;
  padding: 8px;
  margin: 5px 0;
  box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  text-align: left;
}

.seance .module {
  font-weight: bold;
  font-size: 14px;
}

.seance .salle, .seance .prof, .seance .horaire {
  font-size: 12px;
  margin-top: 3px;
}
</style>
</head>
<body>
<header class="app-header">
  <h2>Emploi du temps global</h2>
  <a href="admin_dashboard.php">Retour</a>
  <a class="btn danger" href="export_global_pdf.php">Télécharger emploi du temps global (PDF)</a>

</header>
<main class="container">
  <table class="emploi">
    <tr>
      <th>Jours / Heures</th>
      <?php foreach ($creneaux as $c): ?>
        <th><?= $c[0] ?> - <?= $c[1] ?></th>
      <?php endforeach; ?>
    </tr>
    <?php foreach ($jours as $j): ?>
      <tr>
        <td class="jour"><b><?= $j ?></b></td>
        <?php foreach ($creneaux as $c): ?>
          <td class="case">
            <?php
            $start = toMinutes($c[0]);
            $end   = toMinutes($c[1]);
            foreach ($seances as $s) {
                if ($s['jour']===$j) {
                    $deb = toMinutes($s['heure_debut']);
                    $fin = toMinutes($s['heure_fin']);
                    if ($deb >= $start && $fin <= $end) {
                        echo "<div class='seance'>
                                <div class='module'>📘 ".htmlspecialchars($s['intitule'])."</div>
                                <div class='salle'>🏫 Salle ".htmlspecialchars($s['salle_code'])."</div>
                                <div class='prof'>👨‍🏫 ".htmlspecialchars($s['professeur_nom'])."</div>
                                <div class='horaire'>⏰ ".$s['heure_debut']." - ".$s['heure_fin']."</div>
                              </div>";
                    }
                }
            }
            ?>
          </td>
        <?php endforeach; ?>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
