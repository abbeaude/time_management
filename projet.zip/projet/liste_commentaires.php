<?php
require_once 'db.php';
require_admin(); 


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_id'])) {
    $id = (int)$_POST['comment_id'];
    $reponse = trim($_POST['reponse']);
    if ($reponse !== "") {
        $stmt = $pdo->prepare("UPDATE commentaires SET reponse=? WHERE id=?");
        $stmt->execute([$reponse, $id]);
        $message = "✅ Réponse envoyée avec succès.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_id'])) { 
    $id = (int)$_POST['comment_id']; $reponse = trim($_POST['reponse']); 
    if ($reponse !== "") { $stmt = $pdo->prepare("UPDATE commentaires SET reponse=?, non_repondus=0 WHERE id=?"); 
        $stmt->execute([$reponse, $id]); $message = "✅ Réponse envoyée avec succès."; } }


$stmt = $pdo->query("
  SELECT c.id, c.contenu, c.date_creation, c.reponse, u.nom AS professeur_nom, u.email
  FROM commentaires c
  JOIN users u ON u.id = c.professeur_id
  ORDER BY c.date_creation DESC
");
$commentaires = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Commentaires des professeurs</title>
<link rel="stylesheet" href="style.css">
<style>
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
table th, table td {
  border: 1px solid #333;
  padding: 10px;
  text-align: left;
  vertical-align: top;
}
table th {
  background: #003366;
  color: #fff;
}
.comment {
  background:rgb(41, 25, 164);
  border-radius: 6px;
  padding: 8px;
}
.reponse {
  background:rgb(22, 124, 225);
  border-radius: 6px;
  padding: 8px;
  margin-top: 5px;
  border: 1px solid #27ae60;
}
form.reponse-form textarea {
  width: 100%;
  height: 80px;
  padding: 8px;
  border-radius: 6px;
  border: 1px solid #999;
}
form.reponse-form button {
  margin-top: 5px;
  padding: 8px 12px;
  background: #27ae60;
  color: #fff;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}
.message { color: green; font-weight: bold; }
</style>
</head>
<body>
<header>
  <h2>Commentaires des professeurs</h2>
  <a href="admin_dashboard.php">⬅ Retour au tableau de bord</a>
</header>

<main>
  <?php if (!empty($message)): ?>
    <p class="message"><?= htmlspecialchars($message) ?></p>
  <?php endif; ?>

  <table>
    <tr>
      <th>ID</th>
      <th>Professeur</th>
      <th>Email</th>
      <th>Commentaire</th>
      <th>Date</th>
      <th>Réponse de l’administrateur</th>
    </tr>
    <?php foreach ($commentaires as $c): ?>
      <tr>
        <td><?= htmlspecialchars($c['id']) ?></td>
        <td><?= htmlspecialchars($c['professeur_nom']) ?></td>
        <td><?= htmlspecialchars($c['email']) ?></td>
        <td><div class="comment"><?= nl2br(htmlspecialchars($c['contenu'])) ?></div></td>
        <td><?= htmlspecialchars($c['date_creation']) ?></td>
        <td>
          <?php if ($c['reponse']): ?>
            <div class="reponse"><?= nl2br(htmlspecialchars($c['reponse'])) ?></div>
          <?php else: ?>
            <form method="post" class="reponse-form">
              <input type="hidden" name="comment_id" value="<?= $c['id'] ?>">
              <textarea name="reponse" placeholder="Votre réponse..."></textarea>
              <button type="submit">Envoyer</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
