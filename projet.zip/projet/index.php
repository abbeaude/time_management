<?php
require_once 'db.php';
session_start();

if (is_post()) {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

   
    if ($user && $user['password'] === $password) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'nom' => $user['nom'],
            'email' => $user['email'],
            'role' => $user['role']
        ];
       
        if ($user['role'] === 'admin') {
            redirect('admin_dashboard.php');
        } else {
            redirect('professeur_dashboard.php');
        }
    } else {
        $error = "Identifiants invalides.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>FS Ngaoundéré — Gestion d'emploi du temps</title>
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">
<div class="auth-card">
  <div class="brand">
    <span class="brand-logo">FSN</span>
    <h1>Gestion d'emploi du temps</h1>
    <p>Faculté des Sciences — Université de Ngaoundéré</p>
  </div>
  <?php if (!empty($error)): ?>
    <div class="alert error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="post" class="form-grid">
    <div class="form-field full">
      <label>Email</label>
      <input type="email" name="email" placeholder="ex: xxxx@fs-uni-ndere.cm" required>
    </div>
    <div class="form-field full">
      <label>Mot de passe</label>
      <input type="password" name="password" placeholder="" required>
    </div>
    <button type="submit" class="btn primary">Se connecter</button>
  </form>
  <div class="small-note">
   <!-- Admin par défaut: <b>admin@fs-uni-ndere.cm</b> / <b>1234</b><br> -->
    Les professeurs utilisent leur email et mot de passe créés par l’admin.
  </div>
</div>
<script src="script.js"></script>
</body>
</html>
