<?php
require_once 'db.php';
require_admin();
$id = (int)($_GET['id'] ?? 0);

$seance = null;
if ($id) {
    $st = $pdo->prepare("SELECT * FROM seances WHERE id=?");
    $st->execute([$id]);
    $seance = $st->fetch();
}
$modules = $pdo->query("SELECT id, intitule FROM modules ORDER BY intitule")->fetchAll();
$profs = $pdo->query("SELECT id, nom FROM users WHERE role='professeur' ORDER BY nom")->fetchAll();
$salles = $pdo->query("SELECT id, code FROM salles ORDER BY code")->fetchAll();

if (is_post()) {
    $stmt = $pdo->prepare("UPDATE seances SET module_id=?, professeur_id=?, salle_id=?, jour=?, heure_debut=?, heure_fin=?, commentaire=? WHERE id=?");
    $stmt->execute([
        $_POST['module_id'],
        $_POST['professeur_id'],
        $_POST['salle_id'],
        $_POST['jour'],
        $_POST['heure_debut'],
        $_POST['heure_fin'],
        $_POST['commentaire'] ?? null,
        $id
    ]);
    redirect('admin_dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Modifier séance — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header"><div class="left"><span class="brand-logo small">FSN</span><h2>Modifier une séance</h2></div></header>
<main class="container">
  <?php if (!$seance): ?>
    <div class="alert error">Séance introuvable.</div>
  <?php else: ?>
    <form method="post" class="form-grid card">
      <div class="form-field">
        <label>Module</label>
        <select name="module_id" required>
          <?php foreach ($modules as $m): ?>
            <option value="<?= $m['id'] ?>" <?= $m['id']==$seance['module_id']?'selected':'' ?>><?= htmlspecialchars($m['intitule']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-field">
        <label>Professeur</label>
        <select name="professeur_id" required>
          <?php foreach ($profs as $p): ?>
            <option value="<?= $p['id'] ?>" <?= $p['id']==$seance['professeur_id']?'selected':'' ?>><?= htmlspecialchars($p['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-field">
        <label>Salle</label>
        <select name="salle_id" required>
          <?php foreach ($salles as $s): ?>
            <option value="<?= $s['id'] ?>" <?= $s['id']==$seance['salle_id']?'selected':'' ?>><?= htmlspecialchars($s['code']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-field">
        <label>Jour</label>
        <select name="jour" required>
          <?php foreach (['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'] as $j): ?>
            <option <?= $j===$seance['jour']?'selected':'' ?>><?= $j ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-field">
        <label>Heure début</label>
        <input type="time" name="heure_debut" value="<?= htmlspecialchars($seance['heure_debut']) ?>" required>
      </div>
      <div class="form-field">
        <label>Heure fin</label>
        <input type="time" name="heure_fin" value="<?= htmlspecialchars($seance['heure_fin']) ?>" required>
      </div>
      <div class="form-field full">
        <label>Commentaire</label>
        <input type="text" name="commentaire" value="<?= htmlspecialchars($seance['commentaire'] ?? '') ?>">
      </div>
      <button class="btn primary">Enregistrer</button>
      <a class="btn" href="admin_dashboard.php">Annuler</a>
    </form>
  <?php endif; ?>
</main>
<script src="script.js"></script>
</body>
</html>
