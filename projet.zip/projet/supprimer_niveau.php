<?php
require_once 'db.php';
require_admin();

if (!isset($_GET['id'])) {
    header("Location: liste_niveaux.php?msg=" . urlencode("ID manquant"));
    exit;
}

$id = (int)$_GET['id'];
$stmt = $pdo->prepare("DELETE FROM niveaux WHERE id=?");
$stmt->execute([$id]);

header("Location: liste_niveaux.php?msg=" . urlencode("Niveau supprimé"));
exit;
