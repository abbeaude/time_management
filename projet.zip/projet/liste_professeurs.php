<?php
require_once 'db.php';
require_admin();


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['prof_id'])) {
    $id    = (int)$_POST['prof_id'];
    $nom   = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $mdp   = trim($_POST['motdepasse']);

    if ($mdp !== "") {
       
        $hash = password_hash($mdp, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET nom=?, email=?, motdepasse=? WHERE id=? AND role='professeur'";
        $params = [$nom, $email, $hash, $id];
    } else {
        $sql = "UPDATE users SET nom=?, email=? WHERE id=? AND role='professeur'";
        $params = [$nom, $email, $id];
    }
    $upd = $pdo->prepare($sql);
    $upd->execute($params);
}


$stmt = $pdo->query("SELECT id, nom, email FROM users WHERE role='professeur' ORDER BY nom ASC");
$professeurs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Liste des professeurs</title>
<link rel="stylesheet" href="style.css">
<style>
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
table th, table td {
  border: 1px solid #333;
  padding: 10px;
  text-align: left;
}
table th {
  background: #003366;
  color: #fff;
}
form.inline-form {
  display: flex;
  flex-direction: column;
}
form.inline-form input {
  margin-bottom: 5px;
  padding: 5px;
}
form.inline-form button {
  background: #27ae60;
  color: #fff;
  border: none;
  padding: 6px;
  border-radius: 4px;
  cursor: pointer;
}
.actions a {
  margin-right: 8px;
  text-decoration: none;
  padding: 5px 10px;
  border-radius: 4px;
  color: #fff;
}
.view { background: #4a90e2; }
.delete { background: #c0392b; }
</style>
</head>
<body>
<header>
  <h2>Liste des professeurs</h2>
  <a href="admin_dashboard.php">⬅ Retour au tableau de bord</a>
</header>

<main>
  <table>
    <tr>
      <th>ID</th>
      <th>Nom</th>
      <th>Email</th>
      <th>Modifier infos</th>
      <th>Actions</th>
    </tr>
    <?php foreach ($professeurs as $p): ?>
      <tr>
        <td><?= htmlspecialchars($p['id']) ?></td>
        <td><?= htmlspecialchars($p['nom']) ?></td>
        <td><?= htmlspecialchars($p['email']) ?></td>
        <td>
          
          <form method="post" class="inline-form">
            <input type="hidden" name="prof_id" value="<?= $p['id'] ?>">
            <input type="text" name="nom" value="<?= htmlspecialchars($p['nom']) ?>" required>
            <input type="email" name="email" value="<?= htmlspecialchars($p['email']) ?>" required>
            <input type="password" name="motdepasse" placeholder="Nouveau mot de passe (optionnel)">
            <button type="submit">💾 Enregistrer</button>
          </form>
        </td>
        <td class="actions">
          <a class="view" href="export_pdf.php?professeur_id=<?= $p['id'] ?>">Voir emploi du temps</a>
          <a class="delete" href="supprimer_professeur.php?id=<?= $p['id'] ?>" onclick="return confirm('Supprimer ce professeur ?')">Supprimer</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
