<?php
require_once 'db.php';
require_admin();

$modules = $pdo->query("SELECT id, intitule FROM modules ORDER BY intitule")->fetchAll();
$profs = $pdo->query("SELECT id, nom FROM users WHERE role='professeur' ORDER BY nom")->fetchAll();
$salles = $pdo->query("SELECT id, code FROM salles ORDER BY code")->fetchAll();
$niveaux = $pdo->query("SELECT id, nom FROM niveaux ORDER BY nom")->fetchAll();

if (is_post()) {
    $heureDebut = $_POST['heure_debut'];
    $heureFin   = $_POST['heure_fin'];

    // Calcul de la durée en heures pour validation
    $debut = strtotime($heureDebut);
    $fin   = strtotime($heureFin);
    $duree = ($fin - $debut) / 3600;

    if ($duree > 4) {
        $error = "⚠️ Erreur: une séance ne peut pas dépasser 4 heures.";
    } else {
        // Vérification conflit salle
        $conflictSalle = $pdo->prepare("
          SELECT COUNT(*) FROM seances
          WHERE salle_id=? AND jour=? AND statut='prévu'
          AND NOT (heure_fin <= ? OR heure_debut >= ?)
        ");
        $conflictSalle->execute([$_POST['salle_id'], $_POST['jour'], $heureDebut, $heureFin]);

        // Vérification conflit professeur
        $conflictProf = $pdo->prepare("
          SELECT COUNT(*) FROM seances
          WHERE professeur_id=? AND jour=? AND statut='prévu'
          AND NOT (heure_fin <= ? OR heure_debut >= ?)
        ");
        $conflictProf->execute([$_POST['professeur_id'], $_POST['jour'], $heureDebut, $heureFin]);

        if ($conflictSalle->fetchColumn() > 0) {
            $error = "⚠️ Conflit détecté: la salle est déjà occupée sur ce créneau.";
        } elseif ($conflictProf->fetchColumn() > 0) {
            $error = "⚠️ Conflit détecté: ce professeur est déjà programmé sur ce créneau.";
        } else {
            try {
                // Insertion avec niveau_id et heures brutes
                $stmt = $pdo->prepare("
                  INSERT INTO seances (module_id, professeur_id, salle_id, niveau_id, jour, heure_debut, heure_fin, commentaire, statut)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'prévu')
                ");
                $stmt->execute([
                    $_POST['module_id'], $_POST['professeur_id'], $_POST['salle_id'], $_POST['niveau_id'],
                    $_POST['jour'], $_POST['heure_debut'], $_POST['heure_fin'],
                    $_POST['commentaire'] ?? null
                ]);
                redirect('admin_dashboard.php');
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'chk_heures') !== false) {
                    $error = "⚠️ L'heure de fin doit être après l'heure de début et la durée ≤ 4 heures.";
                } else {
                    $error = "⚠️ Erreur lors de l'enregistrement de la séance.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Planifier une séance — FSN</title>
<link rel="stylesheet" href="style.css">
<style>
.alert.error {
  background: #f8d7da;
  color: #721c24;
  padding: 10px;
  border: 1px solid #f5c6cb;
  border-radius: 4px;
  margin-bottom: 15px;
}
</style>
</head>
<body>
<header class="app-header">
  <div class="left"><span class="brand-logo small">FSN</span><h2>Planifier une séance</h2></div>
</header>
<main class="container">
  <?php if (!empty($error)): ?>
    <div class="alert error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="post" class="form-grid card">
    <div class="form-field">
      <label>Module</label>
      <select name="module_id" required>
        <?php foreach ($modules as $m): ?>
          <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['intitule']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-field">
      <label>Niveau</label>
      <select name="niveau_id" required>
        <?php foreach ($niveaux as $n): ?>
          <option value="<?= $n['id'] ?>"><?= htmlspecialchars($n['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-field">
      <label>Professeur</label>
      <select name="professeur_id" required>
        <?php foreach ($profs as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-field">
      <label>Salle</label>
      <select name="salle_id" required>
        <?php foreach ($salles as $s): ?>
          <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['code']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-field">
      <label>Jour</label>
      <select name="jour" required>
        <?php foreach (['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'] as $j): ?>
          <option><?= $j ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-field"><label>Heure début</label><input type="time" name="heure_debut" required></div>
    <div class="form-field"><label>Heure fin</label><input type="time" name="heure_fin" required></div>
    <div class="form-field full"><label>Commentaire</label><input name="commentaire" placeholder="Remarque (optionnel)"></div>
    <button class="btn primary">Planifier</button>
    <a class="btn" href="admin_dashboard.php">Retour</a>
  </form>
</main>
</body>
</html>
