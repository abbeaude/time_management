<?php
require_once 'db.php';
require_admin();


$parJour = $pdo->query("
  SELECT jour, COUNT(*) AS total
  FROM seances WHERE statut='prévu'
  GROUP BY jour ORDER BY FIELD(jour,'Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi')
")->fetchAll();

e
$topModules = $pdo->query("
  SELECT m.intitule, COUNT(s.id) AS nb
  FROM modules m
  LEFT JOIN seances s ON s.module_id = m.id AND s.statut='prévu'
  GROUP BY m.id ORDER BY nb DESC LIMIT 5
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Statistiques — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header">
  <div class="left"><span class="brand-logo small">FSN</span><h2>Statistiques</h2></div>
  <nav class="nav"><a href="admin_dashboard.php">Accueil</a><a class="active" href="statistiques.php">Statistiques</a><a href="logout.php" class="danger">Déconnexion</a></nav>
</header>
<main class="container">
  <section class="panel">
    <h3>Répartition des séances par jour</h3>
    <div class="grid cards">
      <?php foreach ($parJour as $row): ?>
        <div class="card stat"><h4><?= $row['jour'] ?></h4><div class="big"><?= $row['total'] ?></div></div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="panel">
    <h3>Top modules par nombre de séances</h3>
    <ul class="list">
      <?php foreach ($topModules as $tm): ?>
        <li>
          <div class="list-title"><?= htmlspecialchars($tm['intitule']) ?></div>
          <div class="list-meta"><?= (int)$tm['nb'] ?> séances</div>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
</main>
<script src="script.js"></script>
</body>
</html>
