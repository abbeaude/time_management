<?php
require_once 'db.php';
require_admin();

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM modules WHERE id=?")->execute([$_GET['delete']]);
}

$modules = $pdo->query("
  SELECT m.*, f.nom AS filiere_nom
  FROM modules m
  JOIN filieres f ON f.id=m.filiere_id
  ORDER BY f.nom, m.intitule
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="utf-8"><title>Liste des modules</title><link rel="stylesheet" href="style.css"></head>
<body>
<header class="app-header"><h2>Liste des modules</h2><a href="admin_dashboard.php">Retour</a></header>
<main class="container">
  <table class="card">
    <tr><th>Code</th><th>Intitulé</th><th>Filière</th><th>Actions</th></tr>
    <?php foreach ($modules as $m): ?>
      <tr>
        <td><?= htmlspecialchars($m['code']) ?></td>
        <td><?= htmlspecialchars($m['intitule']) ?></td>
        <td><?= htmlspecialchars($m['filiere_nom']) ?></td>
        <td>
          <a class="btn" href="update_module.php?id=<?= $m['id'] ?>">Modifier</a>
          <a class="btn danger" href="?delete=<?= $m['id'] ?>" onclick="return confirm('Supprimer ce module ?')">Supprimer</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
