<?php
require_once 'db.php';
require_login(); 

$profId = $_SESSION['user']['id'];


$creneaux = [
  ['07:30','09:30'],
  ['09:30','11:30'],
  ['11:30','13:30'],
  ['13:30','15:30'],
  ['15:30','17:30'],
  ['17:30','19:30'],
  ['19:30','20:30']
];
$jours = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];


$stmt = $pdo->prepare("
  SELECT s.*, m.intitule, sa.code AS salle_code
  FROM seances s
  JOIN modules m ON m.id=s.module_id
  JOIN salles sa ON sa.id=s.salle_id
  WHERE s.professeur_id=? AND s.statut='prévu'
");
$stmt->execute([$profId]);
$seances = $stmt->fetchAll();


function toMinutes($time) {
    list($h,$m) = explode(':',$time);
    return $h*60 + $m;
}


$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['commentaire'])) { 
  $commentaire = trim($_POST['commentaire']); 
  if ($commentaire !== "") {
     $stmt = $pdo->prepare("INSERT INTO commentaires (professeur_id, contenu) VALUES (?, ?)");
     $stmt->execute([$profId, $commentaire]); 
     $message = "✅ Votre commentaire a été envoyé à l’administrateur."; 
  } 
}


$stmt = $pdo->prepare("SELECT id, contenu, date_creation, reponse FROM commentaires WHERE professeur_id=? ORDER BY date_creation DESC");
$stmt->execute([$profId]);
$commentaires = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Mon emploi du temps</title>
<link rel="stylesheet" href="style.css">
<style>

table.emploi {
  width: 100%;
  border-collapse: collapse;
  margin-top: 30px;
}
table.emploi th, table.emploi td {
  border: 2px solid #333;
  text-align: center;
  padding: 15px;
  min-width: 130px;
}
table.emploi th {
  background: #003366;
  color: #fff;
  font-size: 14px;
}
table.emploi td {
  background: #f9f9f9;
  vertical-align: top;
}
.jour { background: #e0e0e0; font-weight: bold; }
.case { height: 120px; }
.seance {
  background: linear-gradient(135deg, #4a90e2, #357ab7);
  color: #fff;
  border-radius: 8px;
  padding: 8px;
  margin: 5px 0;
  box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  text-align: left;
}
.seance .module { font-weight: bold; font-size: 14px; }
.seance .salle, .seance .horaire { font-size: 12px; margin-top: 3px; }
.btn {
  display:inline-block; padding:8px 12px; margin:5px;
  border-radius:6px; background:#003366; color:#fff; text-decoration:none;
}
.btn.secondary { background:#27ae60; }
.btn.danger { background:#c0392b; }
.comment-box {
  margin-top: 40px; padding: 20px; border: 2px solid #ccc;
  border-radius: 8px; background: #f4f4f4;
}
.comment-box textarea {
  width: 100%; height: 100px; padding: 10px;
  border-radius: 6px; border: 1px solid #999;
}
.comment-box button {
  margin-top: 10px; padding: 10px 15px;
  background: #003366; color: #fff; border: none;
  border-radius: 6px; cursor: pointer;
}
.message { color: green; font-weight: bold; }
.comment {
  background: #f9f9f9; border-radius: 6px; padding: 10px;
  margin-top: 15px; box-shadow: 0 1px 4px rgba(0,0,0,0.1);
}
.reponse {
  background: #e8f5e9; border-radius: 6px; padding: 8px;
  margin-top: 8px; border: 1px solid #27ae60; color: #2e7d32;
}
.attente { font-size: 12px; color: #c0392b; margin-top: 8px; }
</style>
</head>
<body>
<header class="app-header">
  <h2>Mon emploi du temps</h2>
  <nav>
    <a class="btn" href="logout.php">Déconnexion</a>
    <a class="btn secondary" href="changer_motdepasse.php">Changer mot de passe</a>
    <a class="btn danger" href="professeur_emploi_pdf.php">Télécharger en PDF</a>
  </nav>
</header>
<main class="container">
  <table class="emploi">
    <tr>
      <th>Jours / Heures</th>
      <?php foreach ($creneaux as $c): ?>
        <th><?= $c[0] ?> - <?= $c[1] ?></th>
      <?php endforeach; ?>
    </tr>
    <?php foreach ($jours as $j): ?>
      <tr>
        <td class="jour"><b><?= $j ?></b></td>
        <?php foreach ($creneaux as $c): ?>
          <td class="case">
            <?php
            $start = toMinutes($c[0]);
            $end   = toMinutes($c[1]);
            foreach ($seances as $s) {
                if ($s['jour']===$j) {
                    $deb = toMinutes($s['heure_debut']);
                    $fin = toMinutes($s['heure_fin']);
                    if ($deb >= $start && $fin <= $end) {
                        echo "<div class='seance'>
                                <div class='module'>📘 ".htmlspecialchars($s['intitule'])."</div>
                                <div class='salle'>🏫 Salle ".htmlspecialchars($s['salle_code'])."</div>
                                <div class='horaire'>⏰ ".$s['heure_debut']." - ".$s['heure_fin']."</div>
                              </div>";
                    }
                }
            }
            ?>
          </td>
        <?php endforeach; ?>
      </tr>
    <?php endforeach; ?>
  </table>

  
  <div class="comment-box">
    <h3>Laisser un commentaire à l’administrateur</h3>
    <?php if ($message): ?>
      <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <form method="post">
      <textarea name="commentaire" placeholder="Votre message..."></textarea>
      <button type="submit">Envoyer</button>
    </form>
  </div>

  
  <h3>Mes commentaires et réponses</h3>
  <?php if (empty($commentaires)): ?>
    <p>Vous n’avez pas encore laissé de commentaire.</p>
  <?php else: ?>
    <?php foreach ($commentaires as $c): ?>
      <div class="comment">
        <div><b>Votre commentaire :</b><br><?= nl2br(htmlspecialchars($c['contenu'])) ?></div>
        <div class="date">Envoyé le <?= htmlspecialchars($c['date_creation']) ?></div>
        <?php if ($c['reponse']): ?>
          <div class="reponse">
            <b>Réponse de l’administrateur :</b><br>
            <?= nl2br(htmlspecialchars($c['reponse'])) ?>
          </div>
        <?php else: ?>
          <div class="attente">⏳ En attente de réponse de l’administrateur</div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</main>
</body>
</html>
