<?php
require_once 'db.php';
require_admin();

if (is_post()) {
    $stmt = $pdo->prepare("INSERT INTO salles (code, capacite) VALUES (?, ?)");
    $stmt->execute([$_POST['code'], $_POST['capacite']]);
    redirect('admin_dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Ajouter salle — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header"><div class="left"><span class="brand-logo small">FSN</span><h2>Ajouter une salle</h2></div></header>
<main class="container">
  <form method="post" class="form-grid card">
    <div class="form-field"><label>Code</label><input name="code" required></div>
    <div class="form-field"><label>Capacité</label><input type="number" name="capacite" min="1" value="30" required></div>
    <button class="btn primary">Ajouter</button>
    <a class="btn" href="admin_dashboard.php">Retour</a>
  </form>
</main>
</body>
</html>
