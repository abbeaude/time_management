<?php
require_once 'db.php';
require_admin();

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM departements WHERE id=?")->execute([$_GET['delete']]);
}

$departements = $pdo->query("SELECT * FROM departements ORDER BY nom")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="utf-8"><title>Liste des départements</title><link rel="stylesheet" href="style.css"></head>
<body>
<header class="app-header"><h2>Liste des départements</h2><a href="admin_dashboard.php">Retour</a></header>
<main class="container">
  <table class="card">
    <tr><th>Nom</th><th>Actions</th></tr>
    <?php foreach ($departements as $d): ?>
      <tr>
        <td><?= htmlspecialchars($d['nom']) ?></td>
        <td>
          <a class="btn" href="update_departement.php?id=<?= $d['id'] ?>">Modifier</a>
          <a class="btn danger" href="?delete=<?= $d['id'] ?>" onclick="return confirm('Supprimer ce département ?')">Supprimer</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</main>
</body>
</html>
