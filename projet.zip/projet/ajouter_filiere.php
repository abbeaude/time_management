<?php
require_once 'db.php';
require_admin();

$departements = $pdo->query("SELECT id, nom FROM departements ORDER BY nom")->fetchAll();

if (is_post()) {
    $stmt = $pdo->prepare("INSERT INTO filieres (departement_id, nom) VALUES (?, ?)");
    $stmt->execute([$_POST['departement_id'], $_POST['nom']]);
    redirect('admin_dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Ajouter filière — FSN</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="app-header"><div class="left"><span class="brand-logo small">FSN</span><h2>Ajouter une filière</h2></div></header>
<main class="container">
  <form method="post" class="form-grid card">
    <div class="form-field">
      <label>Département</label>
      <select name="departement_id" required>
        <?php foreach($departements as $d): ?>
          <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-field"><label>Nom</label><input name="nom" required></div>
    <button class="btn primary">Ajouter</button>
    <a class="btn" href="admin_dashboard.php">Retour</a>
  </form>
</main>
</body>
</html>
