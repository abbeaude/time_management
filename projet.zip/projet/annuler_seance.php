<?php
require_once 'db.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
if ($id) {
    $stmt = $pdo->prepare("UPDATE seances SET statut='annulé', commentaire=CONCAT(IFNULL(commentaire,''),' (annulé)') WHERE id=?");
    $stmt->execute([$id]);
}
redirect('admin_dashboard.php');
